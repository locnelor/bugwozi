"use client"

export const useTest = () => {
  return () => {
    console.log('test')
  }
}