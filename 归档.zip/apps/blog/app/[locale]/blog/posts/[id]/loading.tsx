import { Skeleton } from "antd";


const PostsLoading = () => {

  return (
    <div className="container mx-auto">
      <Skeleton />
    </div>
  )
}
export default PostsLoading;