

const WebPage = ()=>{
  return (
    <div></div>
  )
}
export default WebPage;