export const BaseTimeFields = `
createdAt
updatedAt
`
export const BaseFields = `
id
${BaseTimeFields}
`
export const BaseUFields = `
uid
${BaseTimeFields}
`
