

export interface RequestModuleOptions {
    baseUrl: string
}
