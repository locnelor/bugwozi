export * from './prisma.module';
export * from './prisma.service';
export * from "./entity"