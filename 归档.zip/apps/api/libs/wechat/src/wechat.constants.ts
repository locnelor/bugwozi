export const WECHAT_MODULE_OPTIONS = 'WeChatModuleOptions';
export const COMPONENT_MODULE_OPTIONS = 'ComponentModuleOptions';